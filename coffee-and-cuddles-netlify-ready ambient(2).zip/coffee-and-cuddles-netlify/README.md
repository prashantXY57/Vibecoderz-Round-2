# Coffee and Cuddles — Premium Netlify-ready website

A responsive, single-page specialty coffee house website for Dehradun, with an editorial café aesthetic and tactile paper-inspired styling.

## Features
- Warm premium palette with subtle paper grain, brass accents, soft gradients, framed photography, layered shadows, frosted-glass navigation and satin-gloss highlights
- Responsive desktop and mobile layouts with a mobile quick-action dock
- Scroll reveal animations, image hover effects, and reading progress indicator
- Filterable menu with all 21 coffee entries
- Reservation form with client-side validation and on-page demo confirmation
- Story, space/gallery, visit details, and map search link
- Keyboard focus visibility and reduced-motion accessibility support

## Deploy
Upload this folder to Netlify Drop: https://app.netlify.com/drop

## Important limitations
This is a static frontend. The reservation form validates entries and shows a local confirmation; it does not send/store reservations. Connect a form service or backend before accepting real bookings. The phone number is masked in the brief, so the `tel:` link is only a placeholder and must be updated with the cafe's real number. Photos and Google Fonts load from external services.
